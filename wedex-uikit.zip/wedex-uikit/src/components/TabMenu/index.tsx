export { default as TabMenu } from "./TabMenu";
export { default as Tab } from "./Tab";
export type { TabMenuProps, TabProps } from "./types";
